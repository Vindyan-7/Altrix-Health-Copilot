"""Local OCR API for the Altrix demo. Not a diagnostic system."""
from __future__ import annotations
import io, os, traceback
from typing import Any
import fitz
import numpy as np
from PIL import Image
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from paddleocr import PaddleOCR

app = FastAPI(title="Altrix OCR Service", version="1.0.0")
origins = [x.strip() for x in os.getenv("OCR_CORS_ORIGINS", "http://localhost:4321,http://127.0.0.1:4321").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=False, allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["*"])
ocr_engine = None
MAX_BYTES = 10 * 1024 * 1024
MAX_PAGES = 15

@app.get("/health")
def health():
    return {"status": "ok", "service": "altrix-ocr", "engine_loaded": ocr_engine is not None, "max_file_bytes": MAX_BYTES, "max_pdf_pages": MAX_PAGES}

def get_engine():
    global ocr_engine
    if ocr_engine is None:
        # PaddleOCR 3.x API. First launch may download model weights.
        ocr_engine = PaddleOCR(lang="en", use_textline_orientation=True)
    return ocr_engine

def result_to_rows(result: Any):
    rows=[]
    if result is None: return rows
    items = result if isinstance(result, list) else [result]
    for item in items:
        data = getattr(item, "json", None)
        if callable(data): data = data()
        if not isinstance(data, dict): data = getattr(item, "res", None) or {}
        if isinstance(data, dict) and isinstance(data.get("res"), dict): data=data["res"]
        texts = data.get("rec_texts") or []
        scores = data.get("rec_scores") or []
        boxes = data.get("rec_polys") or data.get("dt_polys") or []
        for i, text in enumerate(texts):
            score = scores[i] if i < len(scores) else None
            box = boxes[i] if i < len(boxes) else None
            try: score = float(score) if score is not None else None
            except (ValueError, TypeError): score = None
            rows.append({"text": str(text), "confidence": score, "polygon": np.asarray(box).tolist() if box is not None else None})
    return rows

def image_to_rows(image: Image.Image):
    arr=np.asarray(image.convert("RGB"))
    engine=get_engine()
    try: raw=engine.predict(input=arr)
    except TypeError: raw=engine.predict(arr)
    return result_to_rows(raw)

@app.post("/ocr")
async def run_ocr(file: UploadFile = File(...)):
    name=(file.filename or "upload").lower()
    if not name.endswith((".pdf", ".png", ".jpg", ".jpeg", ".webp")):
        raise HTTPException(415, "Unsupported file type. Upload PDF, PNG, JPG, JPEG, or WEBP.")
    content=await file.read(MAX_BYTES+1)
    if not content: raise HTTPException(400, "The uploaded file is empty.")
    if len(content)>MAX_BYTES: raise HTTPException(413, "File exceeds the 10 MB limit.")
    try:
        pages=[]
        if name.endswith('.pdf'):
            doc=fitz.open(stream=content, filetype='pdf')
            if doc.page_count > MAX_PAGES: raise HTTPException(413, f"PDF has {doc.page_count} pages; maximum is {MAX_PAGES}.")
            for idx, page in enumerate(doc):
                pix=page.get_pixmap(matrix=fitz.Matrix(2,2), alpha=False)
                im=Image.open(io.BytesIO(pix.tobytes('png')))
                rows=image_to_rows(im)
                pages.append({"page":idx+1,"text":"\n".join(x['text'] for x in rows),"lines":rows})
        else:
            im=Image.open(io.BytesIO(content))
            rows=image_to_rows(im)
            pages=[{"page":1,"text":"\n".join(x['text'] for x in rows),"lines":rows}]
        all_lines=[line for page in pages for line in page['lines']]
        scores=[x['confidence'] for x in all_lines if isinstance(x.get('confidence'), (int,float))]
        return {"success":True,"filename":file.filename,"pages":pages,"text":"\n\n".join(p['text'] for p in pages),"line_count":len(all_lines),"mean_confidence":round(sum(scores)/len(scores),4) if scores else None,"notice":"OCR output may contain errors. Verify every value against the original document; this is not medical advice."}
    except HTTPException: raise
    except Exception as exc:
        print("OCR failed:", repr(exc)); traceback.print_exc()
        raise HTTPException(503, "OCR could not process this file. Check service logs and model availability, then retry with a clear PDF or image.")
