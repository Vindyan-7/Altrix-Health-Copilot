# Altrix OCR microservice

Local FastAPI + PaddleOCR 3.x service for English printed documents. It accepts PDF/PNG/JPG/JPEG/WEBP up to 10 MB and 15 PDF pages. OCR is fallible; users must verify all medical values.

Install Python 3.10–3.12, then install `requirements.txt` in a virtual environment and run `uvicorn app:app --host 127.0.0.1 --port 8765`. On first run PaddleOCR may download model weights and need internet access. Check `/health` and `/docs`.

This local service is for the demo and is not a public production endpoint. Do not expose it directly to the internet or upload real patient data without an approved privacy/security deployment.
