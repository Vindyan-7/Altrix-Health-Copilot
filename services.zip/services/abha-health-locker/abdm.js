// ABDM ABHA v3 client (server-side only). Never expose clientSecret or call
// these endpoints from the browser.
import crypto from 'node:crypto';

const ENVS = {
  sandbox: {
    session: 'https://dev.abdm.gov.in/api/hiecm/gateway/v3/sessions',
    base: 'https://abhasbx.abdm.gov.in/abha/api',
    cmId: 'sbx',
  },
  production: {
    session: 'https://apis.abdm.gov.in/api/hiecm/gateway/v3/sessions',
    base: 'https://abha.abdm.gov.in/api/abha',
    cmId: 'abdm',
  },
};

const cfg = ENVS[process.env.ABDM_ENV || 'sandbox'];
if (!cfg) throw new Error('ABDM_ENV must be "sandbox" or "production"');

export class AbdmError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

const pickMessage = (d) =>
  d?.message ||
  d?.error?.message ||
  d?.details?.[0]?.message ||
  d?.error_description ||
  (typeof d?.error === 'string' ? d.error : null) ||
  'ABDM request failed';

/* ---------- gateway session token (cached) ---------- */
let session = null;
let sessionPromise = null;

async function getAccessToken() {
  if (session && session.expiresAt > Date.now() + 60_000) return session.token;
  if (!sessionPromise) {
    sessionPromise = (async () => {
      const res = await fetch(cfg.session, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'REQUEST-ID': crypto.randomUUID(),
          TIMESTAMP: new Date().toISOString(),
          'X-CM-ID': cfg.cmId,
        },
        body: JSON.stringify({
          clientId: process.env.ABDM_CLIENT_ID,
          clientSecret: process.env.ABDM_CLIENT_SECRET,
          grantType: 'client_credentials',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.accessToken) {
        throw new AbdmError(502, 'Could not authenticate with ABDM. Check ABDM_CLIENT_ID / ABDM_CLIENT_SECRET / ABDM_ENV.', data);
      }
      session = { token: data.accessToken, expiresAt: Date.now() + (data.expiresIn || 1200) * 1000 };
      return session.token;
    })().finally(() => {
      sessionPromise = null;
    });
  }
  return sessionPromise;
}

/* ---------- generic ABDM call ---------- */
async function call(path, { method = 'GET', body, xToken } = {}, retry = true) {
  const token = await getAccessToken();
  const headers = {
    'Content-Type': 'application/json',
    'REQUEST-ID': crypto.randomUUID(),
    TIMESTAMP: new Date().toISOString(),
    Authorization: `Bearer ${token}`,
    'X-CM-ID': cfg.cmId,
  };
  if (xToken) headers['X-token'] = `Bearer ${xToken}`;

  const res = await fetch(cfg.base + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }

  if (res.status === 401 && retry) {
    session = null; // gateway token expired, fetch a new one and retry once
    return call(path, { method, body, xToken }, false);
  }
  if (!res.ok) throw new AbdmError(res.status, pickMessage(data), data);
  return data;
}

/* ---------- RSA encryption of sensitive fields ---------- */
let keyCache = null;
async function getPublicKey() {
  if (keyCache && keyCache.exp > Date.now()) return keyCache.key;
  const d = await call('/v3/profile/public/certificate');
  if (!d.publicKey) throw new AbdmError(502, 'ABDM did not return a public key', d);
  const body = d.publicKey.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '').match(/.{1,64}/g).join('\n');
  let key;
  try {
    key = crypto.createPublicKey(`-----BEGIN PUBLIC KEY-----\n${body}\n-----END PUBLIC KEY-----`);
  } catch {
    key = crypto.createPublicKey(`-----BEGIN CERTIFICATE-----\n${body}\n-----END CERTIFICATE-----`);
  }
  keyCache = { key, exp: Date.now() + 6 * 3600_000 };
  return key;
}

// RSA/ECB/OAEPWithSHA-1AndMGF1Padding, base64 output
async function encrypt(value) {
  return crypto
    .publicEncrypt(
      { key: await getPublicKey(), padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha1' },
      Buffer.from(String(value))
    )
    .toString('base64');
}

/* ---------- ABHA login by ABHA number + OTP ---------- */
// If the gateway answers 400 for a scope/otpSystem pair, adjust it here.
export const OTP_METHODS = {
  abha:    { scope: ['abha-login', 'mobile-verify'],  otpSystem: 'abdm'    }, // OTP to the mobile linked with ABHA
  aadhaar: { scope: ['abha-login', 'aadhaar-verify'], otpSystem: 'aadhaar' }, // OTP to the mobile linked with Aadhaar
};

export const digitsOnly = (s) => String(s || '').replace(/\D/g, '');
export const formatAbhaNumber = (d) => `${d.slice(0, 2)}-${d.slice(2, 6)}-${d.slice(6, 10)}-${d.slice(10, 14)}`;

export async function requestLoginOtp(abhaDigits, method) {
  const m = OTP_METHODS[method];
  if (!m) throw new AbdmError(400, 'Unknown OTP method');
  const data = await call('/v3/profile/login/request/otp', {
    method: 'POST',
    body: {
      scope: m.scope,
      loginHint: 'abha-number',
      loginId: await encrypt(formatAbhaNumber(abhaDigits)),
      otpSystem: m.otpSystem,
    },
  });
  if (!data.txnId) throw new AbdmError(502, data.message || 'ABDM did not return a transaction id', data);
  return { txnId: data.txnId, message: data.message || 'OTP sent' };
}

export async function verifyLoginOtp({ txnId, otp, method }) {
  const m = OTP_METHODS[method];
  if (!m) throw new AbdmError(400, 'Unknown OTP method');
  const data = await call('/v3/profile/login/verify', {
    method: 'POST',
    body: {
      txnId,
      scope: m.scope,
      authData: { authMethods: ['otp'], otp: { txnId, otpValue: await encrypt(otp) } },
    },
  });
  if (data.authResult && String(data.authResult).toLowerCase() !== 'success') {
    throw new AbdmError(401, data.message || 'OTP verification failed');
  }

  let profile = data.ABHAProfile || {};
  const xToken = data.tokens?.token;
  if (xToken) {
    // Pull the complete profile; fill any gaps the verify response left out.
    try {
      const full = await call('/v3/profile/account', { xToken });
      const clean = Object.fromEntries(Object.entries(profile).filter(([, v]) => v != null && v !== ''));
      profile = { ...full, ...clean };
    } catch { /* verify response alone is enough */ }
  }
  return normalizeProfile(profile);
}

function normalizeProfile(p) {
  const abhaNumber = p.ABHANumber || p.healthIdNumber;
  if (!abhaNumber) throw new AbdmError(502, 'ABDM did not return an ABHA number', p);
  let dob = p.dob || null;
  if (!dob && p.yearOfBirth) dob = [p.dayOfBirth, p.monthOfBirth, p.yearOfBirth].filter(Boolean).join('-');
  return {
    abha_number: formatAbhaNumber(digitsOnly(abhaNumber)),
    abha_address: p.preferredAbhaAddress || (Array.isArray(p.phrAddress) ? p.phrAddress[0] : null) || null,
    name: p.name || [p.firstName, p.middleName, p.lastName].filter(Boolean).join(' ') || null,
    gender: p.gender || null,
    dob,
    mobile: p.mobile || null,
    email: p.email || null,
    address: p.address || null,
    state_name: p.stateName || null,
    district_name: p.districtName || null,
    pincode: p.pincode || null,
    photo: p.photo || p.profilePhoto || null,
    kyc_verified: !!p.kycVerified,
  };
}
