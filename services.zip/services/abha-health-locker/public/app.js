const $ = (id) => document.getElementById(id);
const BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
BLOOD.forEach((b) => $('fBlood').add(new Option(b, b)));
$('rDate').value = new Date().toISOString().slice(0, 10);

/* ---------- helpers ---------- */
async function api(path, { method = 'GET', json, form } = {}) {
  const res = await fetch('/api' + path, {
    method,
    credentials: 'include',
    headers: json ? { 'Content-Type': 'application/json' } : undefined,
    body: json ? JSON.stringify(json) : form,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(data.error || 'Request failed'); e.status = res.status; throw e; }
  return data;
}
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtAbha = (v) => {
  const d = v.replace(/\D/g, '').slice(0, 14);
  return [d.slice(0, 2), d.slice(2, 6), d.slice(6, 10), d.slice(10, 14)].filter(Boolean).join('-');
};
const busy = (btn, on, label) => { btn.disabled = on; if (label) btn.textContent = label; };

/* ---------- login ---------- */
$('abhaInput').addEventListener('input', (e) => (e.target.value = fmtAbha(e.target.value)));
$('abhaInput').addEventListener('keydown', (e) => e.key === 'Enter' && $('sendOtp').click());
$('otpInput').addEventListener('keydown', (e) => e.key === 'Enter' && $('verifyOtp').click());

let cooldownTimer = null;
function startCooldown(seconds = 30) {
  clearInterval(cooldownTimer);
  let left = seconds;
  const tick = () => {
    $('resendBtn').disabled = left > 0;
    $('resendBtn').textContent = left > 0 ? `Resend OTP (${left}s)` : 'Resend OTP';
    if (left-- <= 0) clearInterval(cooldownTimer);
  };
  tick();
  cooldownTimer = setInterval(tick, 1000);
}

async function sendOtp() {
  $('err1').textContent = '';
  const abhaNumber = $('abhaInput').value;
  if (abhaNumber.replace(/\D/g, '').length !== 14) return ($('err1').textContent = 'ABHA number must be 14 digits.');
  if (!$('consent').checked) return ($('err1').textContent = 'Please give consent to continue.');
  const method = document.querySelector('input[name=method]:checked').value;
  busy($('sendOtp'), true, 'Sending…');
  try {
    const r = await api('/auth/request-otp', { method: 'POST', json: { abhaNumber, method } });
    $('otpMsg').textContent = r.message;
    $('step1').classList.add('hidden');
    $('step2').classList.remove('hidden');
    $('otpInput').value = '';
    $('otpInput').focus();
    startCooldown();
  } catch (e) { $('err1').textContent = e.message; $('err2').textContent = e.message; }
  busy($('sendOtp'), false, 'Send OTP');
}
$('sendOtp').onclick = sendOtp;
$('resendBtn').onclick = () => { $('err2').textContent = ''; sendOtp(); };
$('backBtn').onclick = () => { $('step2').classList.add('hidden'); $('step1').classList.remove('hidden'); $('err2').textContent = ''; };

$('verifyOtp').onclick = async () => {
  $('err2').textContent = '';
  busy($('verifyOtp'), true, 'Verifying…');
  try {
    await api('/auth/verify-otp', { method: 'POST', json: { otp: $('otpInput').value } });
    await openDashboard();
  } catch (e) { $('err2').textContent = e.message; }
  busy($('verifyOtp'), false, 'Verify & sign in');
};

$('logoutBtn').onclick = async () => {
  await api('/auth/logout', { method: 'POST' }).catch(() => {});
  location.reload();
};

/* ---------- dashboard ---------- */
async function openDashboard() {
  const me = await api('/me');
  $('loginView').classList.add('hidden');
  $('dashView').classList.remove('hidden');
  $('logoutBtn').classList.remove('hidden');

  const photo = me.photo ? (me.photo.startsWith('data:') ? me.photo : `data:image/jpeg;base64,${me.photo}`) : null;
  $('avatar').innerHTML = photo ? `<img alt="" src="${esc(photo)}">` : esc((me.name || 'U').charAt(0).toUpperCase());
  $('pName').textContent = me.name || 'ABHA user';
  $('pId').textContent = me.abha_number;
  $('pAddr').textContent = me.abha_address ? `ABHA address: ${me.abha_address}` : '';
  $('kycBadge').textContent = me.kyc_verified ? 'KYC verified ✓' : 'ABHA linked ✓';
  $('fBlood').value = me.blood_group || '';

  const place = [me.district_name, me.state_name, me.pincode].filter(Boolean).join(', ');
  const rows = [['Date of birth', me.dob], ['Gender', me.gender], ['Mobile', me.mobile], ['Email', me.email], ['Address', [me.address, place].filter(Boolean).join(', ')]];
  $('pGrid').innerHTML = rows.filter(([, v]) => v).map(([k, v]) => `<div><dt>${k}</dt><dd>${esc(v)}</dd></div>`).join('');
  await loadReports();
}

$('saveBlood').onclick = async () => {
  try { await api('/me', { method: 'PATCH', json: { bloodGroup: $('fBlood').value || null } }); $('saveBlood').textContent = 'Saved ✓'; }
  catch (e) { alert(e.message); }
  setTimeout(() => ($('saveBlood').textContent = 'Save'), 1500);
};

/* ---------- reports ---------- */
async function loadReports() {
  const list = await api('/reports');
  $('rCount').textContent = list.length ? `(${list.length})` : '';
  $('reportList').innerHTML = list.length
    ? list.map((r) => `<div class="report"><div><div class="rtype">${esc(r.report_type)}</div><div><b>${esc(r.title)}</b></div><div class="rmeta">${esc(r.report_date || 'No date')} · ${esc(r.file_name)} · ${Math.round(r.size_bytes / 1024)} KB</div></div><div class="actions"><button class="ghost" data-a="view" data-id="${r.id}">View</button><button class="danger" data-a="del" data-id="${r.id}">Delete</button></div></div>`).join('')
    : '<div class="empty">No reports saved yet. Upload your first report above.</div>';
}

$('reportList').addEventListener('click', async (e) => {
  const b = e.target.closest('button'); if (!b) return;
  try {
    if (b.dataset.a === 'view') {
      const w = window.open('', '_blank');           // open synchronously so popup blockers allow it
      const { url } = await api(`/reports/${b.dataset.id}/url`);
      if (w) w.location = url; else location.href = url;
    } else if (b.dataset.a === 'del' && confirm('Delete this report permanently?')) {
      await api(`/reports/${b.dataset.id}`, { method: 'DELETE' });
      await loadReports();
    }
  } catch (err) { alert(err.message); }
});

$('addReport').onclick = async () => {
  $('err3').textContent = '';
  const file = $('rFile').files[0];
  if (!$('rTitle').value.trim()) return ($('err3').textContent = 'Please add a title.');
  if (!file) return ($('err3').textContent = 'Please choose a file.');
  if (file.size > 10 * 1024 * 1024) return ($('err3').textContent = 'File is larger than 10 MB.');
  const form = new FormData();
  form.append('title', $('rTitle').value.trim());
  form.append('type', $('rType').value);
  form.append('date', $('rDate').value);
  form.append('file', file);
  busy($('addReport'), true, 'Uploading…');
  try {
    await api('/reports', { method: 'POST', form });
    $('rTitle').value = ''; $('rFile').value = '';
    await loadReports();
  } catch (e) { $('err3').textContent = e.message; }
  busy($('addReport'), false, 'Upload report');
};

/* ---------- boot: resume existing session ---------- */
api('/me').then(openDashboard).catch(() => {});
