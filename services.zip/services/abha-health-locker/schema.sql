-- Run this once in Supabase: SQL Editor > New query > Run

create extension if not exists pgcrypto;

create table if not exists public.users (
  id             uuid primary key default gen_random_uuid(),
  abha_number    text unique not null,
  abha_address   text,
  name           text,
  gender         text,
  dob            text,
  mobile         text,
  email          text,
  address        text,
  state_name     text,
  district_name  text,
  pincode        text,
  photo          text,
  kyc_verified   boolean not null default false,
  blood_group    text,
  last_login_at  timestamptz,
  created_at     timestamptz not null default now()
);

create table if not exists public.reports (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references public.users(id) on delete cascade,
  title        text not null,
  report_type  text not null,
  report_date  date,
  file_path    text not null,
  file_name    text not null,
  mime_type    text not null,
  size_bytes   integer not null,
  created_at   timestamptz not null default now()
);
create index if not exists reports_user_idx on public.reports(user_id, created_at desc);

-- Only the server (service-role key) touches these tables. With RLS on and no
-- policies, the public anon key cannot read or write anything.
alter table public.users   enable row level security;
alter table public.reports enable row level security;

-- Private bucket for the uploaded report files
insert into storage.buckets (id, name, public)
values ('reports', 'reports', false)
on conflict (id) do nothing;
