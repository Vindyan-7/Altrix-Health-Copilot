# ABHA Health Locker

Sign in with an ABHA number (OTP sent by ABDM to the real registered mobile), pull the user's real
ABHA profile, and keep their medical reports in a private per-user locker.

```
Browser (public/)  ──►  Express server (server.js)  ──►  ABDM ABHA v3 APIs   (OTP, profile)
                                    └──────────────────►  Supabase            (users, reports, private file storage)
```

The ABDM client secret and the Supabase service key live only on the server.

## 1. Get ABDM credentials
1. Register at https://sandbox.abdm.gov.in and create a project to get a **client ID and client secret**.
2. Sandbox only works with sandbox/test ABHA accounts (create one in the ABDM sandbox docs/tools), not real people's.
3. For real users you must complete ABDM's onboarding and get **production** credentials, then set `ABDM_ENV=production`.

## 2. Set up Supabase
1. Create a project at https://supabase.com.
2. Open SQL Editor and run `schema.sql` (creates `users`, `reports`, and a private `reports` storage bucket).
3. Copy the project URL and the **service_role** key (Project Settings > API).

## 3. Run
```bash
cp .env.example .env      # fill in the values
npm install
npm start                 # http://localhost:3000
```

## 4. What each endpoint does
| Endpoint | Purpose |
|---|---|
| `POST /api/auth/request-otp` `{abhaNumber, method}` | Encrypts the ABHA number, asks ABDM to send the OTP |
| `POST /api/auth/verify-otp` `{otp}` | Verifies the OTP with ABDM, saves the returned ABHA profile, starts a session |
| `GET/PATCH /api/me` | Profile from ABDM (+ editable blood group) |
| `GET/POST /api/reports`, `GET /api/reports/:id/url`, `DELETE /api/reports/:id` | The user's report locker |

## 5. Using it from your Astro app instead of `public/`
Keep this server as the API. In Astro call the same `/api/...` routes with `credentials: 'include'`.
Same domain (reverse proxy `/api` to this server) is simplest. If the domains differ, set
`CORS_ORIGIN=https://your-astro-site`, `COOKIE_SAMESITE=none`, and use HTTPS everywhere.

## 6. Before real users
- Serve over HTTPS and set `NODE_ENV=production`.
- ABHA data is health data. Follow ABDM's terms and India's DPDP Act: purpose-limited consent (included), a privacy policy, deletion on request.
- Rate limits are in-memory; use a shared store (e.g. Redis) if you run several server instances.
- Logs never contain OTPs or ABHA numbers. Keep it that way.

## Troubleshooting
- `Could not authenticate with ABDM`: wrong client ID/secret or wrong `ABDM_ENV`.
- ABDM replies 400 on request-otp: the `scope` / `otpSystem` pair for that method may differ in your
  ABDM environment. Adjust `OTP_METHODS` at the bottom of the config section in `abdm.js`; the error
  message ABDM returned is printed in the server log.
- OTP never arrives: the ABHA must exist in the same environment (sandbox accounts for sandbox) and have a mobile linked.


## Altrix integration
This service is bundled under `services/abha-health-locker` and is linked from the Altrix UI at `/abha-locker`. It remains a separate Express service with separate authentication; configure `PUBLIC_ABHA_LOCKER_URL` in the Altrix environment to the deployed locker origin. See the repository root `INTEGRATED_DEMO_GUIDE.md`.
