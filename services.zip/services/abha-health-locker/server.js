import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createClient } from '@supabase/supabase-js';
import { AbdmError, requestLoginOtp, verifyLoginOtp, digitsOnly, formatAbhaNumber, OTP_METHODS } from './abdm.js';

/* ---------- config ---------- */
for (const k of ['ABDM_CLIENT_ID', 'ABDM_CLIENT_SECRET', 'SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'JWT_SECRET']) {
  if (!process.env[k]) { console.error(`Missing env var ${k} (see .env.example)`); process.exit(1); }
}
if (process.env.JWT_SECRET.length < 32) { console.error('JWT_SECRET must be at least 32 characters'); process.exit(1); }

const { JWT_SECRET, CORS_ORIGIN, PORT = 3000 } = process.env;
const isProd = process.env.NODE_ENV === 'production';
const sameSite = process.env.COOKIE_SAMESITE || 'lax';
const BUCKET = 'reports';
const REPORT_TYPES = ['Lab report', 'Prescription', 'Radiology / Scan', 'Discharge summary', 'Vaccination', 'Other'];
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

const cookieOpts = (maxAge) => ({ httpOnly: true, secure: isProd || sameSite === 'none', sameSite, maxAge, path: '/' });
const hash = (s) => crypto.createHash('sha256').update(s).digest('hex');

/* ---------- app ---------- */
const app = express();
app.set('trust proxy', 1);
app.use(helmet());
if (CORS_ORIGIN) app.use(cors({ origin: CORS_ORIGIN.split(','), credentials: true }));
app.use(express.json({ limit: '50kb' }));
app.use(cookieParser());

// Block cross-site state-changing requests (CSRF) unless the origin is allowed
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (!origin) return next();
  const allowed = [`${req.protocol}://${req.get('host')}`, ...(CORS_ORIGIN ? CORS_ORIGIN.split(',') : [])];
  if (allowed.includes(origin)) return next();
  res.status(403).json({ error: 'Origin not allowed' });
});

/* ---------- rate limits ---------- */
const msg = (error) => ({ error });
const otpIp = rateLimit({ windowMs: 10 * 60_000, limit: 10, standardHeaders: true, legacyHeaders: false, message: msg('Too many OTP requests. Try again in a few minutes.') });
const otpPerId = rateLimit({
  windowMs: 10 * 60_000, limit: 3, standardHeaders: true, legacyHeaders: false,
  keyGenerator: (req) => 'abha:' + hash(digitsOnly(req.body?.abhaNumber)),
  message: msg('Too many OTP requests for this ABHA number. Try again in a few minutes.'),
  validate: false,
});
const verifyIp = rateLimit({ windowMs: 10 * 60_000, limit: 10, standardHeaders: true, legacyHeaders: false, message: msg('Too many attempts. Try again in a few minutes.') });

/* ---------- auth ---------- */
function auth(req, res, next) {
  try {
    req.userId = jwt.verify(req.cookies.session, JWT_SECRET).sub;
    next();
  } catch {
    res.status(401).json({ error: 'Not signed in' });
  }
}

app.post('/api/auth/request-otp', otpIp, otpPerId, async (req, res, next) => {
  try {
    const digits = digitsOnly(req.body?.abhaNumber);
    const method = req.body?.method;
    if (digits.length !== 14) return res.status(400).json({ error: 'ABHA number must be 14 digits.' });
    if (!OTP_METHODS[method]) return res.status(400).json({ error: 'Choose where to receive the OTP.' });

    const { txnId, message } = await requestLoginOtp(digits, method);
    // Bind the transaction to this ABHA number + method so verify cannot be tampered with
    const ctx = jwt.sign({ txnId, abha: digits, method }, JWT_SECRET, { expiresIn: '10m' });
    res.cookie('otp_ctx', ctx, cookieOpts(10 * 60_000));
    res.json({ message });
  } catch (e) { next(e); }
});

app.post('/api/auth/verify-otp', verifyIp, async (req, res, next) => {
  try {
    const otp = String(req.body?.otp || '').trim();
    if (!/^\d{6}$/.test(otp)) return res.status(400).json({ error: 'Enter the 6-digit OTP.' });

    let ctx;
    try { ctx = jwt.verify(req.cookies.otp_ctx, JWT_SECRET); }
    catch { return res.status(400).json({ error: 'OTP session expired. Please request a new OTP.' }); }

    const profile = await verifyLoginOtp({ txnId: ctx.txnId, otp, method: ctx.method });

    // The profile ABDM returns must belong to the number the user typed
    if (digitsOnly(profile.abha_number) !== ctx.abha) {
      return res.status(401).json({ error: 'ABHA verification mismatch.' });
    }

    const { data: user, error } = await supabase
      .from('users')
      .upsert({ ...profile, last_login_at: new Date().toISOString() }, { onConflict: 'abha_number' })
      .select('id')
      .single();
    if (error) throw error;

    res.clearCookie('otp_ctx', { path: '/' });
    res.cookie('session', jwt.sign({ sub: user.id }, JWT_SECRET, { expiresIn: '7d' }), cookieOpts(7 * 24 * 3600_000));
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('session', { path: '/' });
  res.clearCookie('otp_ctx', { path: '/' });
  res.json({ ok: true });
});

/* ---------- profile ---------- */
const PROFILE_COLS = 'abha_number, abha_address, name, gender, dob, mobile, email, address, state_name, district_name, pincode, photo, kyc_verified, blood_group, created_at';

app.get('/api/me', auth, async (req, res, next) => {
  try {
    const { data, error } = await supabase.from('users').select(PROFILE_COLS).eq('id', req.userId).single();
    if (error) return res.status(401).json({ error: 'Not signed in' });
    res.json(data);
  } catch (e) { next(e); }
});

app.patch('/api/me', auth, async (req, res, next) => {
  try {
    const bg = req.body?.bloodGroup || null;
    if (bg !== null && !BLOOD_GROUPS.includes(bg)) return res.status(400).json({ error: 'Invalid blood group' });
    const { error } = await supabase.from('users').update({ blood_group: bg }).eq('id', req.userId);
    if (error) throw error;
    res.json({ ok: true });
  } catch (e) { next(e); }
});

/* ---------- reports ---------- */
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024, files: 1 } });

function sniffMime(buf) {
  if (buf.subarray(0, 4).toString() === '%PDF') return 'application/pdf';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'image/png';
  if (buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') return 'image/webp';
  return null;
}

app.get('/api/reports', auth, async (req, res, next) => {
  try {
    const { data, error } = await supabase
      .from('reports')
      .select('id, title, report_type, report_date, file_name, mime_type, size_bytes, created_at')
      .eq('user_id', req.userId)
      .order('report_date', { ascending: false, nullsFirst: false })
      .order('created_at', { ascending: false });
    if (error) throw error;
    res.json(data);
  } catch (e) { next(e); }
});

app.post('/api/reports', auth, upload.single('file'), async (req, res, next) => {
  let storedPath = null;
  try {
    const title = String(req.body?.title || '').trim();
    const type = String(req.body?.type || '');
    const date = req.body?.date ? String(req.body.date) : null;
    if (!title || title.length > 120) return res.status(400).json({ error: 'Title is required (max 120 characters).' });
    if (!REPORT_TYPES.includes(type)) return res.status(400).json({ error: 'Invalid report type.' });
    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) return res.status(400).json({ error: 'Invalid date.' });
    if (!req.file) return res.status(400).json({ error: 'Choose a file to upload.' });

    const mime = sniffMime(req.file.buffer);
    if (!mime) return res.status(400).json({ error: 'Only PDF, JPG, PNG or WEBP files are allowed.' });

    const safeName = req.file.originalname.replace(/[^\w.\-]+/g, '_').slice(-80) || 'report';
    storedPath = `${req.userId}/${crypto.randomUUID()}-${safeName}`;
    const up = await supabase.storage.from(BUCKET).upload(storedPath, req.file.buffer, { contentType: mime, upsert: false });
    if (up.error) throw up.error;

    const { data, error } = await supabase
      .from('reports')
      .insert({ user_id: req.userId, title, report_type: type, report_date: date, file_path: storedPath, file_name: safeName, mime_type: mime, size_bytes: req.file.size })
      .select('id')
      .single();
    if (error) throw error;
    res.status(201).json({ id: data.id });
  } catch (e) {
    if (storedPath) await supabase.storage.from(BUCKET).remove([storedPath]).catch(() => {});
    next(e);
  }
});

app.get('/api/reports/:id/url', auth, async (req, res, next) => {
  try {
    const { data: row } = await supabase.from('reports').select('file_path').eq('id', req.params.id).eq('user_id', req.userId).maybeSingle();
    if (!row) return res.status(404).json({ error: 'Report not found' });
    const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(row.file_path, 60);
    if (error) throw error;
    res.json({ url: data.signedUrl });
  } catch (e) { next(e); }
});

app.delete('/api/reports/:id', auth, async (req, res, next) => {
  try {
    const { data: row } = await supabase.from('reports').select('file_path').eq('id', req.params.id).eq('user_id', req.userId).maybeSingle();
    if (!row) return res.status(404).json({ error: 'Report not found' });
    await supabase.storage.from(BUCKET).remove([row.file_path]);
    const { error } = await supabase.from('reports').delete().eq('id', req.params.id).eq('user_id', req.userId);
    if (error) throw error;
    res.json({ ok: true });
  } catch (e) { next(e); }
});

/* ---------- static frontend + errors ---------- */
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), 'public')));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

app.use((err, req, res, _next) => {
  if (err instanceof AbdmError) {
    // Log details for you; never log OTPs or full identifiers
    console.error('[ABDM]', err.status, err.message, JSON.stringify(err.details || {}).slice(0, 500));
    const status = err.status === 429 ? 429 : err.status >= 500 ? 502 : 400;
    return res.status(status).json({ error: err.message });
  }
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'File is larger than 10 MB.' : 'Upload failed.' });
  }
  console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

app.listen(PORT, () => console.log(`ABHA Health Locker running on http://localhost:${PORT} (ABDM ${process.env.ABDM_ENV || 'sandbox'})`));
